/// <reference types="cypress" />

// Task 1 - Customer Service > Track your package
// Includes validations for main menu, navigation, and final destination page.

describe('Task 1 - Customer Service > Track your package', () => {
  it('validates main menu, navigates to Customer Service, and opens Track your package', () => {
    // Step 1: Open Amazon homepage
    cy.visit('/')

    // Step 2: Validate main menu links (part of assignment requirement)
    cy.reload()
    const menuLabels = [/Today.?s Deals/i, /Customer Service|Help/i, /Deals/i]
    menuLabels.forEach(rx => {
      cy.contains('a', rx, { matchCase: false, timeout: 8000 }).should('exist')
    })

    // Step 3: Dismiss possible overlays (cookies/region)
    cy.dismissOverlaysIfAny()

    // Step 4: Navigate to Customer Service (or Help)
    const csRegex = /Customer Service|Help/i

    cy.get('body').then(($body) => {
      const headerLink = $body.find('a').filter((i, el) => csRegex.test(el.innerText || ''))
      if (headerLink.length > 0) {
        cy.wrap(headerLink.first()).click({ force: true })
        return
      }

      const hamburger = $body.find('#nav-hamburger-menu')
      if (hamburger.length > 0) {
        cy.wrap(hamburger).click({ force: true })
        cy.get('body').then(($b2) => {
          const menuItem = $b2.find('#hmenu-content a.hmenu-item, #hmenu-content *')
            .filter((i, el) => csRegex.test(el.innerText || ''))
          if (menuItem.length > 0) {
            cy.wrap(menuItem.first()).click({ force: true })
          } else {
            cy.contains(csRegex, { timeout: 8000 }).first().click({ force: true })
          }
        })
        return
      }

      cy.get('footer').scrollIntoView()
      cy.contains('footer a, footer *', csRegex, { timeout: 8000 }).first().click({ force: true })
    })

    // Step 5: Ensure we are on a help/customer service page
    cy.url().should('include', '/help')

    // Step 6: Click "Where's My Stuff" button (XPath + fallback)
    const XPATH_WIMS = '//*[@id="hub-gateway-app-unauth"]/div[2]/div/div/div[1]/ul/li[3]/label'
    const CS_SCOPE = 'main, #help-gateway, [data-cel-widget="cs-topics"], [data-cel-widget="cs-hub"]'
    const WIMS_TEXT = /Where('?| i)s My Stuff/i

    cy.xpath(XPATH_WIMS, { timeout: 6000 })
      .then(($els) => {
        if ($els.length > 0) {
          cy.wrap($els.first()).should('be.visible').click({ force: true })
        } else {
          cy.get(CS_SCOPE, { timeout: 10000 })
            .first()
            .within(() => {
              cy.contains('a,button,div,label,span', WIMS_TEXT, { timeout: 10000 })
                .first()
                .click({ force: true })
            })
        }
      })

    // Step 7: Click the next tile/button by XPath (Track your package) + fallback
    const XPATH_NEXT = '//*[@id="hub-gateway-app-unauth"]/div[2]/div/div/div[2]/div[1]/div[1]/div'
    const NEXT_TEXT = /Track your package/i

    cy.xpath(XPATH_NEXT, { timeout: 6000 })
      .then(($els) => {
        if ($els.length > 0) {
          cy.wrap($els.first()).should('be.visible').click({ force: true })
        } else {
          cy.get(CS_SCOPE, { timeout: 10000 })
            .first()
            .within(() => {
              cy.contains('a,button,div,label,span', NEXT_TEXT, { timeout: 10000 })
                .first()
                .click({ force: true })
            })
        }
      })

    // Step 8: Handle login redirect if it appears (continue the flow for the assignment)
    cy.url().then((u) => {
      if (u.includes('signin')) {
        cy.visit('https://www.amazon.com/gp/css/order-history')
      }
    })

    // Step 9: Validate the final page loads successfully
    cy.contains(/Your Orders|Order History|Track Package/i, { timeout: 10000 }).should('be.visible')
  })
})